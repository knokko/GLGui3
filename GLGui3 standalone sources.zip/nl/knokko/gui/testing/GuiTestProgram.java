package nl.knokko.gui.testing;

public interface GuiTestProgram {
	
	void test(GuiTestHelper test);
}