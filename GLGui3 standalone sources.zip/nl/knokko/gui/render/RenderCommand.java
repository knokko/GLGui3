package nl.knokko.gui.render;

interface RenderCommand {
	
	void execute(GuiRenderer guiRenderer);
}